<?php
  require_once'session.php';
  require_once'database.php';
  $user_id=$_SESSION['id'];
  $select_user="SELECT * FROM user_form WHERE id=$user_id";
  $query_select_user =mysqli_query($db,$select_user);
  $assoc_select_user=mysqli_fetch_assoc($query_select_user);

  //For use the active class in the menu select
  $exp= explode('/', $_SERVER['PHP_SELF']);
  $end_exp= end($exp);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Twitter -->
    <meta name="twitter:site" content="@themepixels">
    <meta name="twitter:creator" content="@themepixels">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Starlight">
    <meta name="twitter:description" content="Premium Quality and Responsive UI for Dashboard.">
    <meta name="twitter:image" content="http://themepixels.me/starlight/img/starlight-social.png">

    <!-- Facebook -->
    <meta property="og:url" content="http://themepixels.me/starlight">
    <meta property="og:title" content="Starlight">
    <meta property="og:description" content="Premium Quality and Responsive UI for Dashboard.">

    <meta property="og:image" content="http://themepixels.me/starlight/img/starlight-social.png">
    <meta property="og:image:secure_url" content="http://themepixels.me/starlight/img/starlight-social.png">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="600">

    <!-- Meta -->
    <meta name="description" content="Premium Quality and Responsive UI for Dashboard.">
    <meta name="author" content="ThemePixels">

    <title>Starlight Responsive Bootstrap 4 Admin Template</title>

    <!-- vendor css -->
    <link href="assets/lib/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="assets/lib/Ionicons/css/ionicons.css" rel="stylesheet">
    <link href="assets/lib/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet">

    <link href="assets/lib/highlightjs/github.css" rel="stylesheet">
    <link href="assets/lib/datatables/jquery.dataTables.css" rel="stylesheet">
    <link href="assets/lib/select2/css/select2.min.css" rel="stylesheet">


    <!-- Starlight CSS -->
    <link rel="stylesheet" href="assets/css/starlight.css">
    
  </head>

  <body>

    <!-- ########## START: LEFT PANEL ########## -->
    <div class="sl-logo"><a href=""><i class="icon ion-android-star-outline"></i> Admin</a></div>
    <div class="sl-sideleft">
      <div class="input-group input-group-search">
        <input type="search" name="search" class="form-control" placeholder="Search">
        <span class="input-group-btn">
          <button class="btn"><i class="fa fa-search"></i></button>
        </span><!-- input-group-btn -->
      </div><!-- input-group -->

      <label class="sidebar-label">Navigation</label>
      <div class="sl-sideleft-menu">
        <a href="dashboard.php" class="sl-menu-link <?=$end_exp=='dashboard.php'?'active':''?>">
          <div class="sl-menu-item">
            <i class="menu-item-icon icon ion-ios-home-outline tx-22"></i>
            <span class="menu-item-label">Dashboard</span>
          </div><!-- menu-item -->
        </a><!-- sl-menu-link -->
        <a href="user.php" class="sl-menu-link <?=$end_exp=='user.php'?'active':''?>">
          <div class="sl-menu-item">
            <i class="menu-item-icon icon ion-person-add tx-20"></i>
            <span class="menu-item-label">User</span>
          </div><!-- menu-item -->
        </a><!-- sl-menu-link -->
        <a href="banner.php" class="sl-menu-link <?=$end_exp=='banner.php'?'active':''?>">
          <div class="sl-menu-item">
            <i class="menu-item-icon fa fa-camera tx-20"></i>
            <span class="menu-item-label">Banners</span>
          </div><!-- menu-item -->
        </a><!-- sl-menu-link -->
        <a href="social.php" class="sl-menu-link <?=$end_exp=='social.php'?'active':''?>">
          <div class="sl-menu-item">
            <i class="menu-item-icon fa fa-send tx-20"></i>
            <span class="menu-item-label">Socials</span>
          </div><!-- menu-item -->
        </a><!-- sl-menu-link -->
        <a href="services.php" class="sl-menu-link <?=$end_exp=='services.php'?'active':''?>">
          <div class="sl-menu-item">
            <i class="menu-item-icon fa fa-magic tx-20"></i>
            <span class="menu-item-label">Services</span>
          </div><!-- menu-item -->
        </a><!-- sl-menu-link -->
        <a href="education.php" class="sl-menu-link <?=$end_exp=='education.php'?'active':''?>">
          <div class="sl-menu-item">
            <i class="menu-item-icon fa fa-graduation-cap tx-20"></i>
            <span class="menu-item-label">Education</span>
          </div><!-- menu-item -->
        </a><!-- sl-menu-link -->
        <a href="portfolio.php" class="sl-menu-link <?=$end_exp=='portfolio.php'?'active':''?>">
          <div class="sl-menu-item">
            <i class="menu-item-icon ion-man tx-20"></i>
            <span class="menu-item-label">Portfolio</span>
          </div><!-- menu-item -->
        </a><!-- sl-menu-link -->
        <a href="contact.php" class="sl-menu-link <?=$end_exp=='contact.php'?'active':''?>">
          <div class="sl-menu-item">
            <i class="menu-item-icon fa fa-envelope-o tx-20"></i>
            <span class="menu-item-label">Messages</span>
          </div><!-- menu-item -->
        </a><!-- sl-menu-link -->
        <a href="partner.php" class="sl-menu-link <?=$end_exp=='partner.php'?'active':''?>">
          <div class="sl-menu-item">
            <i class="menu-item-icon fa fa-sitemap tx-20"></i>
            <span class="menu-item-label">Partners</span>
          </div><!-- menu-item -->
        </a><!-- sl-menu-link -->
        <a href="settings.php" class="sl-menu-link <?=$end_exp=='settings.php'?'active':''?>">
          <div class="sl-menu-item">
            <i class="menu-item-icon fa fa-gear tx-20"></i>
            <span class="menu-item-label">Settings</span>
          </div><!-- menu-item -->
        </a><!-- sl-menu-link -->
        <a target="_blank" href="../index.php" class="sl-menu-link <?=$end_exp=='../index.php'?'active':''?>">
          <div class="sl-menu-item">
            <i class="menu-item-icon fa fa-globe tx-20"></i>
            <span class="menu-item-label">Home</span>
          </div><!-- menu-item -->
        </a><!-- sl-menu-link -->
      </div><!-- sl-sideleft-menu -->

      <br>
    </div><!-- sl-sideleft -->
    <!-- ########## END: LEFT PANEL ########## -->

    <!-- ########## START: HEAD PANEL ########## -->
    <div class="sl-header">
      <div class="sl-header-left">
        <div class="navicon-left hidden-md-down"><a id="btnLeftMenu" href=""><i class="icon ion-navicon-round"></i></a></div>
        <div class="navicon-left hidden-lg-up"><a id="btnLeftMenuMobile" href=""><i class="icon ion-navicon-round"></i></a></div>
      </div><!-- sl-header-left -->
      <div class="sl-header-right">
        <nav class="nav">
          <div class="dropdown">
            <a href="" class="nav-link nav-link-profile" data-toggle="dropdown">
              <span class="logged-name"><?=$_SESSION['name']?></span>
              <img src="uploads/<?=$assoc_select_user['profile_image']?>" class="wd-32 rounded-circle" alt="">
            </a>
            <div class="dropdown-menu dropdown-menu-header wd-200">
              <ul class="list-unstyled user-profile-nav">
                <li><a href="edit-profile.php"><i class="icon ion-ios-person-outline"></i> Edit Profile</a></li>
                <li><a href=""><i class="icon ion-ios-gear-outline"></i> Settings</a></li>
                <li><a href=""><i class="icon ion-ios-download-outline"></i> Downloads</a></li>
                <li><a href=""><i class="icon ion-ios-star-outline"></i> Favorites</a></li>
                <li><a href="change-password.php"><i class="icon fa fa-lock"></i> Change Password</a></li>
                <li><a href="logout.php"><i class="icon ion-power"></i> Sign Out</a></li>
              </ul>
            </div><!-- dropdown-menu -->
          </div><!-- dropdown -->
        </nav>
        <div class="navicon-right">
          <a id="btnRightMenu" href="" class="pos-relative">
            <i class="icon ion-ios-bell-outline"></i>
            <!-- start: if statement -->
            <span class="square-8 bg-danger"></span>
            <!-- end: if statement -->
          </a>
        </div><!-- navicon-right -->
      </div><!-- sl-header-right -->
    </div><!-- sl-header -->
    <!-- ########## END: HEAD PANEL ########## -->

    <?php 
      $message = "SELECT COUNT(*) as total_msg, id, name, message FROM contacts WHERE status = 1 ORDER BY id DESC";
      $message_q = mysqli_query($db, $message);
      $message_assoc = mysqli_fetch_assoc($message_q);
     ?>

    <!-- ########## START: RIGHT PANEL ########## -->
    <div class="sl-sideright">
      <ul class="nav nav-tabs nav-fill sidebar-tabs" role="tablist">
        <li class="nav-item">
          <a class="nav-link active" data-toggle="tab" role="tab" href="#messages">Messages (<?=$message_assoc['total_msg']?>)</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="tab" role="tab" href="#notifications">Notifications (8)</a>
        </li>
      </ul><!-- sidebar-tabs -->

      <!-- Tab panes -->
      <div class="tab-content">
        <div class="tab-pane pos-absolute a-0 mg-t-60 active" id="messages" role="tabpanel">
          <div class="media-list">
            <!-- loop starts here -->
            <?php foreach ($message_q as $value): ?>
              
            <a href="message-single.php?user_id=<?= $value['id'] ?>" class="media-list-link">
              <div class="media">
                <!-- <img src="../img/img3.jpg" class="wd-40 rounded-circle" alt=""> -->
                <div class="media-body">
                  <p class="mg-b-0 tx-medium tx-gray-800 tx-13"><?= $value['name'] ?></p>
                  <span class="d-block tx-11 tx-gray-500">2 minutes ago</span>
                  <p class="tx-13 mg-t-10 mg-b-0"><?= $value['message'] ?></p>
                </div>
              </div><!-- media -->
            </a>
            <!-- loop ends here -->
            <?php endforeach; ?>
          </div><!-- media-list -->
          <div class="pd-15">
            <a href="" class="btn btn-secondary btn-block bd-0 rounded-0 tx-10 tx-uppercase tx-mont tx-medium tx-spacing-2">
            <?php if ($message_assoc['total_msg'] < 1): ?> No Messages</a>
            <?php else: ?> View More Messages</a>
            <?php endif ?>
          </div>
        </div><!-- #messages -->

        <div class="tab-pane pos-absolute a-0 mg-t-60 overflow-y-auto" id="notifications" role="tabpanel">
          <div class="media-list">
            <!-- loop starts here -->
            <a href="" class="media-list-link read">
              <div class="media pd-x-20 pd-y-15">
                <img src="../img/img8.jpg" class="wd-40 rounded-circle" alt="">
                <div class="media-body">
                  <p class="tx-13 mg-b-0 tx-gray-700"><strong class="tx-medium tx-gray-800">Suzzeth Bungaos</strong> tagged you and 18 others in a post.</p>
                  <span class="tx-12">October 03, 2017 8:45am</span>
                </div>
              </div><!-- media -->
            </a>
            <!-- loop ends here -->
            <a href="" class="media-list-link read">
              <div class="media pd-x-20 pd-y-15">
                <img src="../img/img9.jpg" class="wd-40 rounded-circle" alt="">
                <div class="media-body">
                  <p class="tx-13 mg-b-0 tx-gray-700"><strong class="tx-medium tx-gray-800">Mellisa Brown</strong> appreciated your work <strong class="tx-medium tx-gray-800">The Social Network</strong></p>
                  <span class="tx-12">October 02, 2017 12:44am</span>
                </div>
              </div><!-- media -->
            </a>
            <a href="" class="media-list-link read">
              <div class="media pd-x-20 pd-y-15">
                <img src="../img/img10.jpg" class="wd-40 rounded-circle" alt="">
                <div class="media-body">
                  <p class="tx-13 mg-b-0 tx-gray-700">20+ new items added are for sale in your <strong class="tx-medium tx-gray-800">Sale Group</strong></p>
                  <span class="tx-12">October 01, 2017 10:20pm</span>
                </div>
              </div><!-- media -->
            </a>
            <a href="" class="media-list-link read">
              <div class="media pd-x-20 pd-y-15">
                <img src="../img/img5.jpg" class="wd-40 rounded-circle" alt="">
                <div class="media-body">
                  <p class="tx-13 mg-b-0 tx-gray-700"><strong class="tx-medium tx-gray-800">Julius Erving</strong> wants to connect with you on your conversation with <strong class="tx-medium tx-gray-800">Ronnie Mara</strong></p>
                  <span class="tx-12">October 01, 2017 6:08pm</span>
                </div>
              </div><!-- media -->
            </a>
            <a href="" class="media-list-link read">
              <div class="media pd-x-20 pd-y-15">
                <img src="../img/img8.jpg" class="wd-40 rounded-circle" alt="">
                <div class="media-body">
                  <p class="tx-13 mg-b-0 tx-gray-700"><strong class="tx-medium tx-gray-800">Suzzeth Bungaos</strong> tagged you and 12 others in a post.</p>
                  <span class="tx-12">September 27, 2017 6:45am</span>
                </div>
              </div><!-- media -->
            </a>
            <a href="" class="media-list-link read">
              <div class="media pd-x-20 pd-y-15">
                <img src="../img/img10.jpg" class="wd-40 rounded-circle" alt="">
                <div class="media-body">
                  <p class="tx-13 mg-b-0 tx-gray-700">10+ new items added are for sale in your <strong class="tx-medium tx-gray-800">Sale Group</strong></p>
                  <span class="tx-12">September 28, 2017 11:30pm</span>
                </div>
              </div><!-- media -->
            </a>
            <a href="" class="media-list-link read">
              <div class="media pd-x-20 pd-y-15">
                <img src="../img/img9.jpg" class="wd-40 rounded-circle" alt="">
                <div class="media-body">
                  <p class="tx-13 mg-b-0 tx-gray-700"><strong class="tx-medium tx-gray-800">Mellisa Brown</strong> appreciated your work <strong class="tx-medium tx-gray-800">The Great Pyramid</strong></p>
                  <span class="tx-12">September 26, 2017 11:01am</span>
                </div>
              </div><!-- media -->
            </a>
            <a href="" class="media-list-link read">
              <div class="media pd-x-20 pd-y-15">
                <img src="../img/img5.jpg" class="wd-40 rounded-circle" alt="">
                <div class="media-body">
                  <p class="tx-13 mg-b-0 tx-gray-700"><strong class="tx-medium tx-gray-800">Julius Erving</strong> wants to connect with you on your conversation with <strong class="tx-medium tx-gray-800">Ronnie Mara</strong></p>
                  <span class="tx-12">September 23, 2017 9:19pm</span>
                </div>
              </div><!-- media -->
            </a>
          </div><!-- media-list -->
        </div><!-- #notifications -->

      </div><!-- tab-content -->
    </div><!-- sl-sideright -->
    <!-- ########## END: RIGHT PANEL ########## --->
